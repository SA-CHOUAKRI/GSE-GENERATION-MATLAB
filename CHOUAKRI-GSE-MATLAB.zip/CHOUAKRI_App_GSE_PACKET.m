function CHOUAKRI_App_GSE_PACKET

% CHOUAKRI_App_GSE_PACKET UI -User Interface- interactively genrate GSE -Generic Stream Encapsulation- packets destinated for
% DVB-S2 IP Transmission developed by CHOUAKRI Sid Ahmed based on the refernced document ETSI TS 102 606: "Digital Video Broadcasting (DVB); Generic Stream Encapsulation (GSE) 
% Protocol".   
% The UI permits the whole GSE Packet generation cases for 'Type 2: EtherType compatible Type Fields' 
% It consists on 3 drop-downs that, in series, genrates correctly the GSE packet,
% that are: "PADDING,PDU,RESET" Primary one, "NO-FRAGM (full GSE packet),
% FRGMNT" and at last "MAC 6 BYTES ,MAC 3 BYTES"
% It calls 2 fundamental Matlab-coded functions,that are :
% CHOUAKRI_KERNEL_GSE_PCKT.m and  CHOUAKRI_FRAGMT_GSE.m
%   


% % % % L_T_I='00'; Frag_ID_DECIM0='1';   PRTCL_TYP='800'; LBL_TYP='A1B2C3D4E5F6';
% % % % PDU_PCKT='123456789ABCDEF123456789ABCDEF123456789ABCDEF123456789ABCDEF123456789ABCDEF123456789ABCDEF123456789ABCDEF123456789ABCDEF123456789ABCDEF123456789ABCDEF123456789ABCDEF123456789ABCDEF';
% % % % lengts= '11, 15, 19';
% % % % data = '11, 15, 19'; N_PAD=3;


% Create figure window
fig = uifigure;
fig.Name = "CHOUAKRI App_GSE";

% Manage app layout
gl = uigridlayout(fig, [10 4]);         gl.RowHeight = {30,'1x'};           gl.ColumnWidth = {'1x'};

% % % % % % % % % % Create UI components
lbl  = uilabel(gl);      lbl.HorizontalAlignment = 'right';          dd = uidropdown(gl);
% Configure UI component appearance
lbl.Text = "PADDING-PDU-RESET";          dd.Items = ["PADDING","PDU","RESET"];        dd.Value = "PADDING";

lbl21  = uilabel(gl);        lbl21.HorizontalAlignment = 'right';      lbl21.Text = "PADDING BYTES"; 

ef22 = uieditfield(gl,"text", ...
    "InputType","text",...
    "Placeholder",  "ENTER PADDING BYTES NUMBER");
lbl23  = uilabel(gl);    lbl23.HorizontalAlignment = 'right';      dd24 = uidropdown(gl);
lbl23.Text = "GSE PCKET TYPE:";          dd24.Items = ["NO-FRAGM","FRGMNT"];        dd24.Value = "NO-FRAGM";

         
lbl31  = uilabel(gl);       lbl31.HorizontalAlignment = 'right';        lbl31.Text = "EtherType PROTOCOL";     
ef32 = uieditfield(gl,"text", ...
    "InputType","text",...
    "Placeholder",  "ENTER EtherType PROTOCOL");

lbl33  = uilabel(gl);     lbl33.HorizontalAlignment = 'right';     dd34 = uidropdown(gl);
lbl33.Text = "LABEL TYPE";          dd34.Items = ["MAC 6 BYTES","MAC 3 BYTES"];        dd34.Value = "MAC 6 BYTES";

lbl41  = uilabel(gl);         lbl41.HorizontalAlignment = 'right';      lbl41.Text = "MAC 6-BYTES";     
ef42 = uieditfield(gl,"text", ...
    "InputType","text",...
    "Placeholder",  "ENTER MAC 6-BYTES");
lbl43  = uilabel(gl);       lbl43.HorizontalAlignment = 'right';        lbl43.Text = "MAC 3-BYTES";     
ef44 = uieditfield(gl,"text", ...
    "InputType","text",...
    "Placeholder",  "ENTER MAC 3-BYTES");
 
ef51 = uieditfield(gl,"text", ...
    "InputType","text",...
    "Placeholder",  "DISPLAY GSE LENGTH");
    
ef52 = uieditfield(gl,"text", ...
    "InputType","text",...
    "Placeholder",  "DISPLAY TOTAL LENGTH");
ef61 = uieditfield(gl,"text", ...
    "InputType","text",...
    "Placeholder",  "ENTER FRAGMNT-ID");
ef62 = uieditfield(gl,"text", ...
    "InputType","text",...
    "Placeholder",  "ENTER FRAGMNT FIRST LENGTHS");

ef71 = uieditfield(gl,"text", ...
    "InputType","text",...
    "Placeholder",  "ENTER PDU PACKET");
ef81 = uieditfield(gl,"text", ...
    "InputType","text",...
    "Placeholder",  "DISPLAY FULL GSE PACKET");

txt = ["FIRST"; "CONTIN."; "..."; "..."; "END"];
         txa = uitextarea(gl, ...
             "Value",txt);

% % % % txt = ["FIRST"; "CONTIN."; "..."; "END"];
% % % % textarea = uitextarea("Value",txt);

% Lay out UI components
lbl.Layout.Row = 1;     lbl.Layout.Column = 1;     dd.Layout.Row = 1;       dd.Layout.Column = 2;

lbl21.Layout.Row = 2;      lbl21.Layout.Column = 1;      ef22.Layout.Row = 2;      ef22.Layout.Column = 2;
lbl23.Layout.Row = 2;      lbl23.Layout.Column = 3;      dd24.Layout.Row = 2;      dd24.Layout.Column = 4;

lbl31.Layout.Row = 3;      lbl31.Layout.Column = 1;      ef32.Layout.Row = 3;      ef32.Layout.Column = 2;
lbl33.Layout.Row = 3;      lbl33.Layout.Column = 3;      dd34.Layout.Row = 3;      dd34.Layout.Column = 4;

lbl41.Layout.Row = 4;      lbl41.Layout.Column = 1;      ef42.Layout.Row = 4;      ef42.Layout.Column = 2;
lbl43.Layout.Row = 4;      lbl43.Layout.Column = 3;      ef44.Layout.Row = 4;      ef44.Layout.Column = 4;

ef51.Layout.Row = 5;       ef51.Layout.Column = 1;       ef52.Layout.Row = 5;      ef52.Layout.Column = 2;

ef61.Layout.Row = 6;       ef61.Layout.Column = 1;       ef62.Layout.Row = 6;      ef62.Layout.Column = [2 4];

ef71.Layout.Row = 7;       ef71.Layout.Column = [1 4];       ef81.Layout.Row = 8;       ef81.Layout.Column = [1 4];

txa.Layout.Row = [9 10];      txa.Layout.Column = [1 4];

% Assign callback function to drop-down
 dd.ValueChangedFcn =    {@changePlotType,ef22,dd24,ef32,dd34,ef42,ef44,ef51,ef52,ef61,ef62,ef71,ef81,txa};
 % % % % dd24.ValueChangedFcn = {@changePlotType1,ef22,ef32,dd34,ef42,ef44,ef51,ef52,ef61,ef62,ef71,ef81};% % % % dd34.ValueChangedFcn = {@createWordCloud,ef22,dd24,ef32,dd34,ef42,ef44,ef51,ef52,ef61,ef62,ef71,ef81};
                        
function changePlotType(~,event,ef22,dd24,ef32,dd34,ef42,ef44,ef51,ef52,ef61,ef62,ef71,ef81,txa)         % % % % % % % % %% Program app behavior
% % % % % % event
NPADs=ef22.Value;
        NPAD=str2num(NPADs);
Frag_ID_DECIM0=ef61.Value;
PRTCL_TYP=ef32.Value;
LABEL_TYP = dd34.Value;
FULL_FRAG = dd24.Value;
PDU_PCKT= ef71.Value;
        type = event.Value;
switch type
    case "PADDING"
        % % % % clear ef71
        % % % NPADs=ef22.Value;          % % % NPAD=str2num(NPADs);               % % % Frag_ID_DECIM0=ef61.Value;               % % %     PRTCL_TYP=ef32.Value;
                                disp('padding1')
                    [GSE_Length,Total_Length, uni_gse_packet] = CHOUAKRI_KERNEL_GSE_PCKT('0','0','00',NPAD,Frag_ID_DECIM0,PRTCL_TYP,'123456','11110000');
                    
              disp('padding2')

              
      ef51.Value= num2str(GSE_Length);       
      % % % % % ef52.Value =num2str(Total_Length);         
      ef81.Value= uni_gse_packet;

    case "PDU"        
        disp('PDU1')
        switch FULL_FRAG
    case "NO-FRAGM"   
        disp('NO-FRAGM')
        switch LABEL_TYP
            case        "MAC 6 BYTES"
                disp('MAC 6 BYTES')
                LBL_TYP=ef42.Value;
                 LTI='00';
            case        "MAC 3 BYTES"
                 disp('MAC 3 BYTES')
                 LBL_TYP=ef44.Value;
                  LTI='01';
        end                                      
        [GSE_Length, Total_Length, uni_gse_packet] = CHOUAKRI_KERNEL_GSE_PCKT('1','1',LTI,NPAD,Frag_ID_DECIM0,PRTCL_TYP,LBL_TYP,PDU_PCKT);
        
         ef51.Value= num2str(GSE_Length);
        % % % % ef52.Value =Total_Length;
        ef81.Value= uni_gse_packet;

    case "FRGMNT"
        disp('FRAGM')
        % % % % [GSE_Length1,Total_Length, uni_gse_packet1]=CHOUAKRI_KERNEL_GSE_PCKT('1','1','00',NPAD,'1','800','123456','11110000111100001111000011110000');
        % % % %  ef51.Value= num2str(GSE_Length1);
        % % % % % % % % ef52.Value =num2str(Total_Length);
        % % % % ef81.Value= num2str(uni_gse_packet1);
        lengts=ef62.Value
        disp('NO-FRAGM')
        switch LABEL_TYP
            case        "MAC 6 BYTES"
                disp('MAC 6 BYTES')
                LBL_TYP=ef42.Value;
                 LTI='00';
            case        "MAC 3 BYTES"
                 disp('MAC 3 BYTES')
                 LBL_TYP=ef44.Value;
                  LTI='01';
        end          

        [GSE_Length, TOTALLL_LENGTHHH, uni_gse_packet] = CHOUAKRI_FRAGMT_GSE(LTI, NPAD, Frag_ID_DECIM0, PRTCL_TYP, LBL_TYP, PDU_PCKT, lengts)
       GSE_Length
       TOTALLL_LENGTHHH
       uni_gse_packet

        ef52.Value =num2str(bin2dec(TOTALLL_LENGTHHH));
ef51.Value= num2str(cell2mat(GSE_Length));


 str0=uni_gse_packet{1,1};
% % % str1=" ";

data1=lengts    
C1 = strsplit(data1,', ');          length(C1);
formatSpec = "%s";
 for kkk=2:(length(C1)+1)
    % % % uni_gse_packet{1,kkk}
    % % % % str2=sprintf(formatSpec,uni_gse_packet{1,kkk})
   str0=horzcat(str0,...
       uni_gse_packet{1,kkk})
    % % % % str1=vertcat(str0,str2)
 end
% % % % % % ssssssssss=string(uni_gse_packet)
% % % % % % rrrrrrrr=ssssssssss(1,3)
% % % % % %         ef81.Value= rrrrrrrr;
         ef81.Value= str0;

 txa.Value=uni_gse_packet;

         
        

        end
    case "RESET"
        txa.Value = "FRAGMENT GSE PACKET "
        ef52.Value ="TOTAL LENGTH ";
ef51.Value= "GSE LENGTH ";
ef81.Value= "FULL GSE PACKET ";;

end
end


end



