 % % % % % % function [GSE_Length, Total_Length, uni_gse_packet] = mono_gse_nov_flow(SI,EI,L_T_I,N_PAD,Frag_ID_DECIM0,PRTCL_TYP,LBL_TYP,PDU_PCKT)



 function [GSE_Length, Total_Length, uni_gse_packet] = CHOUAKRI_KERNEL_GSE_PCKT(SI,EI,L_T_I,N_PAD,Frag_ID_DECIM0,PRTCL_TYP,LBL_TYP,PDU_PCKT)


disp('PROGRAMMM');

% % % % % % % % % GENERATE PPPPPPPDUUUUUUUU   PPPPAAAAAACEEEEETTTTT
  
 % % % % % % % % PDU_LOAD=hexToBinaryVector(PDU_PCKT,length(PDU_PCKT)*4);
for lll=1:length(PDU_PCKT)
   aa1(lll)=hex2dec(PDU_PCKT(lll));
    % % % % % aa2(lll)=dec2bin(aa1(lll),4);
end

 aa2=dec2bin(aa1,4);
PDU_LOAD=reshape(aa2,1,length(aa2)*4);
    




PDU_LOAD=aa2(1,:); 
for hhh=2:length(PDU_PCKT)
   PDU_LOAD= horzcat(PDU_LOAD,aa2(hhh,:));
end


% % % % SGE_DATA = []; 
Frag_ID_DECIM = str2num(Frag_ID_DECIM0);


% % % % protocoltype
Protocol_Type1= hex2dec(PRTCL_TYP);
         Protocol_Type= dec2bin(Protocol_Type1,16);


% % % % label type
         if L_T_I =='00'

         Byte_Label_6_1= hex2dec(LBL_TYP);
         Byte_Label_6= dec2bin(Byte_Label_6_1,48);
        % % % % % C = horzcat(C,Byte_Label_6);
        LBL=Byte_Label_6;
      
         
    elseif L_T_I=='01'

        Byte_Label_3_1= hex2dec(LBL_TYP);
         Byte_Label_3= dec2bin(Byte_Label_3_1,24);
        % % % % % % C = horzcat(C,Byte_Label_3);
        LBL=Byte_Label_3;
        
         end





C = ['']; 
C_hex= []; 
C = [SI,EI,L_T_I]; 

if (SI=="0"  &&   EI=="0"  && L_T_I=="00") 
   
        Padding_bits = dec2bin(0,8)
        for j=1:N_PAD
            C = horzcat(C,Padding_bits);
        end
        C_hex =C;
        GSE_Length=N_PAD;
        Total_Length=N_PAD;
        % % % uni_gse_packet= C_hex;
        gselng=GSE_Length
% % % % % % ttllngth=Total_Lengthc

gg=size(C);
for ee=1:gg(2)
    bbb(ee)=logical(str2num(C(ee)));
end
C_hex=binaryVectorToHex(bbb)


uni_gse_packet = C_hex(2:end)
        
else    
    GSE_LEN_cdt=[char(SI),char(EI),char(L_T_I)]  
    switch GSE_LEN_cdt
        case '1100'
            % % % PDU_N_BYTES_MAX=4087
            GSE_Length = (8 + (length(PDU_PCKT)/2));
            % % % % X = ['GSE LENGTH = ', num2str(GSE_Length), ' bits'];
            % % % % disp(X);
             Total_Length=[];

        case '1101'
          % % % % PDU_N_BYTES_MAX=4090
          GSE_Length = 5+(length(PDU_PCKT)/2);            
      % % % X = ['GSE LENGTH = ', num2str(GSE_Length), ' bits'];
      % % % disp(X);
       Total_Length=[];
        
        case '1000'
            % % % % % PDU_N_BYTES_MAX=4084
          GSE_Length = 11+(length(PDU_PCKT)/2);
 % % % % X = ['GSE LENGTH = ', num2str(GSE_Length), ' bits'];
            % % % % disp(X);
            CRC_GSE{Frag_ID_DECIM}=[];       GSE_CRC =  [] ;
           

       case '1001'
          % % % % % PDU_N_BYTES_MAX=4087
          GSE_Length = 8+(length(PDU_PCKT)/2);         
       % % % % X = ['GSE LENGTH = ', num2str(GSE_Length), ' bits'];
            % % % % disp(X);
         CRC_GSE{Frag_ID_DECIM}=[];       GSE_CRC =  [] ;
        
        case '0011'            
            % % % % % PDU_N_BYTES_MAX=4094
          GSE_Length = 1+(length(PDU_PCKT)/2);
         % % % % X = ['GSE LENGTH = ', num2str(GSE_Length), ' bits'];
            % % % % disp(X);
             Total_Length=[];
               % % % % CRC_GSE{Frag_ID_DECIM}=[];       GSE_CRC =  [] ;
        

              case '0010'            
            % % % % % PDU_N_BYTES_MAX=4094
          GSE_Length = 1+(length(PDU_PCKT)/2);
         % % % % X = ['GSE LENGTH = ', num2str(GSE_Length), ' bits'];
            % % % % disp(X);
             Total_Length=[];
  % % % % % CRC_GSE{Frag_ID_DECIM}=[];       GSE_CRC =  [] ;
        
        
        case '0111'
            DU_N_BYTES_MAX=4090
          GSE_Length = 5+(length(PDU_PCKT)/2);
         % % % % X = ['GSE LENGTH = ', num2str(GSE_Length), ' bits'];
            % % % % disp(X);
             Total_Length=[];


             case '0110'
            DU_N_BYTES_MAX=4090
          GSE_Length = 5+(length(PDU_PCKT)/2);
         % % % % X = ['GSE LENGTH = ', num2str(GSE_Length), ' bits'];
            % % % % disp(X);
             Total_Length=[];


        
        otherwise
        disp('other value');

    end
    
    GSE_Length_bin= dec2bin(GSE_Length ,12);
    C = [C, GSE_Length_bin] ;

  % % % % % % % % % % % % % % % % %   INTRODUCE   FRAGGGGGGGGGG IIIIDDDDDDDD
    if  (SI=='0') | (EI=='0')
        Frag_ID= dec2bin(Frag_ID_DECIM,8);
       
    C = horzcat(C,Frag_ID);
    C_dec=bin2dec(C);
    C_hex=dec2hex(C_dec);
    end
    
    
 % % % %   INTRODUCE TTTTOOOTTTTTTTTALLLLL  LLEEEEENNGGGGGGGHHHHHHH
 if (SI=='1') && (EI=='0')
    CRC_GSE{Frag_ID_DECIM}=[]; 
    
    if L_T_I =='00'
          TOTAL_LNGTH=6;
      elseif   L_T_I =='01'
          TOTAL_LNGTH=3;
    end             
 
 TOTAL_LNGTH= TOTAL_LNGTH + 2 + (length(PDU_PCKT)/2);

Total_Length= dec2bin(TOTAL_LNGTH,16)
     C = horzcat(C,Total_Length);     
     CRC_GSE{Frag_ID_DECIM}=[ CRC_GSE{Frag_ID_DECIM},Total_Length]
     C_dec=bin2dec(C);
    C_hex=dec2hex(C_dec);
    CRC_GSE{Frag_ID_DECIM}=[ Total_Length,Protocol_Type,LBL];
end


% % % % % % % % %  INTRODUCE PPPProtocol_TTTTTTTTTTType
if (SI=='1')
        % % % % % Protocol_Type1= hex2dec(PRTCL_TYP);
        % % % % %  Protocol_Type= dec2bin(Protocol_Type1,16);
    C = horzcat(C,Protocol_Type, LBL);  
    % % % % C = horzcat(C,Byte_Label_6);
        
% % % % % % % % % %     INTROCUCE LLLLAAAAABBBBELLLL TTTTTTTYYYYYPPPEEEE
    % % % % % % % if L_T_I =='00'
    % % % % % % % 
    % % % % % % %      Byte_Label_6_1= hex2dec(LBL_TYP);
    % % % % % % %      Byte_Label_6= dec2bin(Byte_Label_6_1,48);
    % % % % % % %     C = horzcat(C,Byte_Label_6);
    % % % % % % %     LBL=Byte_Label_6;
    % % % % % % % 
    % % % % % % % 
    % % % % % % % elseif L_T_I=='01'
    % % % % % % % 
    % % % % % % %     Byte_Label_3_1= hex2dec(LBL_TYP);
    % % % % % % %      Byte_Label_3= dec2bin(Byte_Label_3_1,24);
    % % % % % % %     C = horzcat(C,Byte_Label_3);
    % % % % % % %     LBL=Byte_Label_3;
    % % % % % % % 
    % % % % % % % end
end


% % % % rrCRC_GSE{Frag_ID_DECIM}=[ Total_Length,Protocol_Type,LBL];
C = horzcat(C,PDU_LOAD)
% % % % % % % % % % % % % % % % CRC_GSE{Frag_ID_DECIM}=[ Total_Length,Protocol_Type,LBL,PDU_LOAD];
% % % % CRC_GSE{Frag_ID_DECIM}=[ Total_Length,Protocol_Type,LBL,PDU_LOAD];

% % % % % % % % % %  if (SI=='0') && (EI=='1')
% % % % % % % % % % 
% % % % % % % % % %   % % % disp('CRCCCCC');
% % % % % % % % % %   % % % length(CRC_GSE{Frag_ID_DECIM})/32
% % % % % % % % % % 
% % % % % % % % % %  CRC_GSE{Frag_ID_DECIM}=[ Total_Length,Protocol_Type,LBL,PDU_LOAD]; 
% % % % % % % % % % 
% % % % % % % % % %   % % % % hGen = comm.CRCGenerator([32 26 23 22 16 12 11 10 8 7 5 4 2 1 0]);
% % % % % % % % % % hGen =comm.CRCGenerator('Polynomial','z^32 + z^26 + z^23 + z^22 + z^16 + z^12 + z^11 + z^10 + z^8 + z^7 + z^5 + z^4 + z^2 + z + 1');
% % % % % % % % % % release(hGen)
% % % % % % % % % % hGen.InitialConditions=1;
% % % % % % % % % % 
% % % % % % % % % % crcCfg = crcConfig(Polynomial='z^32 + z^26 + z^23 + z^22 + z^16 + z^12 + z^11 + z^10 + z^8 + z^7 + z^5 + z^4 + z^2 + z + 1', ...
% % % % % % % % % %     InitialConditions=1,...
% % % % % % % % % %     ChecksumsPerFrame=1);
% % % % % % % % % %     % % % InitialConditions=1, ...
% % % % % % % % % %     % % % DirectMethod=true, ...ChecksumsPerFrame=2
% % % % % % % % % %     % % % FinalXOR=1);
% % % % % % % % % % 
% % % % % % % % % % 
% % % % % % % % % % 
% % % % % % % % % % jj=length(CRC_GSE{Frag_ID_DECIM});
% % % % % % % % % % GSE_CRC_DOUBLE =[];
% % % % % % % % % %      for ii=1:jj(1)
% % % % % % % % % %          GSE_CRC_DOUBLE = horzcat( GSE_CRC_DOUBLE, bin2dec(CRC_GSE{Frag_ID_DECIM}(ii)));
% % % % % % % % % %      end
% % % % % % % % % % 
% % % % % % % % % % xxx=logical(GSE_CRC_DOUBLE)';
% % % % % % % % % % codeword_GSE = step(hGen, xxx);
% % % % % % % % % % crcSeq = crcGenerate(xxx,crcCfg);
% % % % % % % % % % 
% % % % % % % % % % disp('codeword_GSE')
% % % % % % % % % % codwrd=length(codeword_GSE')
% % % % % % % % % % 
% % % % % % % % % % disp('crcSeq')
% % % % % % % % % % codwrd1=length(crcSeq')
% % % % % % % % % % 
% % % % % % % % % % checkSum =  crcSeq(end-32+1:end)'
% % % % % % % % % % 
% % % % % % % % % % chkcrt=[]; 
% % % % % % % % % % for oo=1:length(checkSum)
% % % % % % % % % %     chk(oo)=num2str(checkSum(oo));
% % % % % % % % % %     chkcrt=[chkcrt,  chk(oo)]; 
% % % % % % % % % % end
% % % % % % % % % % % % % % chkcrt = num2str(checkSum,"char");
% % % % % % % % % % 
% % % % % % % % % %      % % % % CRC_GSE{Frag_ID_DECIM}=[ CRC_GSE{Frag_ID_DECIM},Protocol_Type,LBL]; 
% % % % % % % % % % 
% % % % % % % % % %      C = horzcat(C,chkcrt);
% % % % % % % % % % 
% % % % % % % % % % end




% % % C = horzcat(C,PDU_LOAD)



gg=size(C);
for ee=1:gg(2)
    bbb(ee)=logical(str2num(C(ee)));
end
C_hex=binaryVectorToHex(bbb)


gselng=GSE_Length
ttllngth=Total_Length
uni_gse_packet = C_hex

% % % SGE_DATA
% % % % % % C0 = [SI,EI,L_T_I]; 
% % % % % %  C1 = [C0, GSE_Length_bin] ;
% % % % % %  C2 = horzcat(C1,Frag_ID);
% % % % % %   C3 = horzcat(C2,Total_Length);
% % % % % %    C4 = horzcat(C3,Protocol_Type);
% % % % % %     C5 = horzcat(C4,Byte_Label_6);
% % % % % %     C6 = horzcat(C5,PDU_LOAD');
   
    
% % % 
% % % % ccccrrrrcccc=CRC_GSE{Frag_ID_DECIM}
% % % % PDU_LOAD
% % % % CRC_GSE{Frag_ID_DECIM}=[ CRC_GSE{Frag_ID_DECIM},PDU_LOAD]; 
% % % % % % if ((SI=='0') & (EI=='1')     )      % % % % % % % %      CALCULATE CRC_32  (32 b)
% % % % % % 
% % % % % % hGen = comm.CRCGenerator([32 26 23 22 16 12 11 10 8 7 5 4 2 1 0]);
% % % % % % release(hGen)
% % % % % % hGen.InitialConditions=1;
% % % % % % 
% % % % % % 
% % % % % % 
% % % % % % jj=size(CRC_GSE{Frag_ID_DECIM});
% % % % % % GSE_CRC_DOUBLE =[];
% % % % % %      for ii=1:jj(1)
% % % % % %          GSE_CRC_DOUBLE = horzcat( GSE_CRC_DOUBLE, bin2dec(CRC_GSE{Frag_ID_DECIM}(ii)));
% % % % % %      end
% % % % % % 
% % % % % % 
% % % % % % codeword_GSE = step(hGen, logical(GSE_CRC_DOUBLE)');
% % % % % % 
% % % % % % end





end
 end
