% % % % function [GSE_Length, Total_Length, uni_gse_packet] = fragmt_GSE_NOV_2024(SI,EI,L_T_I,N_PAD,Frag_ID_DECIM0,PRTCL_TYP,LBL_TYP,PDU_PCKT,lengts)
% % % % function [GSE_Length, Total_Length, uni_gse_packet] = CHOUAKRI_KERNEL_GSE_PCKT(SI,EI,L_T_I,N_PAD,Frag_ID_DECIM0,PRTCL_TYP,LBL_TYP,PDU_PCKT)
% % % % L_T_I='00'; Frag_ID_DECIM0='1';   PRTCL_TYP='800'; LBL_TYP='A1B2C3D4E5F6';
% % % % PDU_PCKT='123456789ABCDEF123456789ABCDEF123456789ABCDEF123456789ABCDEF123456789ABCDEF123456789ABCDEF123456789ABCDEF123456789ABCDEF123456789ABCDEF123456789ABCDEF123456789ABCDEF123456789ABCDEF';
% % % % lengts= '11, 15, 19';
% % % % data = '11, 15, 19'; N_PAD=3;
% % % % function [GSE_Length, Total_Length, uni_gse_packet] = CHOUAKRI_KERNEL_GSE_PCKT(SI,EI,L_T_I,N_PAD,Frag_ID_DECIM0,PRTCL_TYP,LBL_TYP,PDU_PCKT)

function [GSE_Length, TOTALLL_LENGTHHH, uni_gse_packet] = CHOUAKRI_FRAGMT_GSE(L_T_I, N_PAD, Frag_ID_DECIM0, PRTCL_TYP, LBL_TYP, PDU_PCKT, lengts)

disp('FRAGMNT FUNCT')

Frag_ID_DECIM = str2num(Frag_ID_DECIM0);

if L_T_I =='00'
    TOTAL_LNGTH=6;       Byte_Label_6_1= hex2dec(LBL_TYP);       Byte_Label_6= dec2bin(Byte_Label_6_1,48);         LBL=Byte_Label_6;
elseif   L_T_I =='01'
    TOTAL_LNGTH=3;       Byte_Label_3_1= hex2dec(LBL_TYP);       Byte_Label_3= dec2bin(Byte_Label_3_1,24);         LBL=Byte_Label_3;
end    

TOTAL_LNGTH= TOTAL_LNGTH + 2 + (length(PDU_PCKT)/2);    TOTALLL_LENGTHHH = dec2bin(TOTAL_LNGTH,16)

Protocol_Type1= hex2dec(PRTCL_TYP);    PROTOCOLLL_TYPEEE= dec2bin(Protocol_Type1,16)

if L_T_I =='00'
    TOTAL_LNGTH=6;       Byte_Label_6_1= hex2dec(LBL_TYP);       Byte_Label_6= dec2bin(Byte_Label_6_1,48);         LBL=Byte_Label_6;
elseif   L_T_I =='01'
    TOTAL_LNGTH=3;       Byte_Label_3_1= hex2dec(LBL_TYP);       Byte_Label_3= dec2bin(Byte_Label_3_1,24);         LBL=Byte_Label_3;
end    

LABELLL=LBL

data=lengts    
C = strsplit(data,', ');          length(C);
for rr=1:length(C)
        B(rr)= (str2num(C{1,rr}))*2
end

PCK_FRG{1}=PDU_PCKT(1:B(1));
[GSE_Length1, Total_Length1, uni_gse_packet1] = CHOUAKRI_KERNEL_GSE_PCKT('1','0',L_T_I,N_PAD,Frag_ID_DECIM0,PRTCL_TYP,LBL_TYP,PCK_FRG{1});
GSE_Length{1}=GSE_Length1;         uni_gse_packet{1}= uni_gse_packet1;

deb=1;            fn=B(1);
for intrmd=2:length(C)
    deb=deb+B(intrmd-1);           fn=fn+B(intrmd);     PCK_FRG{intrmd}=PDU_PCKT(deb:fn)
    [GSE_Length1, Total_Length1, uni_gse_packet1] = CHOUAKRI_KERNEL_GSE_PCKT('0','0','11',N_PAD,Frag_ID_DECIM0,PRTCL_TYP,LBL_TYP,PCK_FRG{intrmd}); 
    GSE_Length{intrmd}=GSE_Length1;                     uni_gse_packet{intrmd}= uni_gse_packet1;
end

PCK_FRG{length(C)+1}=PDU_PCKT(fn+1:end);
[GSE_Length1, ~, uni_gse_packet1] = CHOUAKRI_KERNEL_GSE_PCKT('0','1','11',N_PAD,Frag_ID_DECIM0,PRTCL_TYP,LBL_TYP,PCK_FRG{length(C)+1});
GSE_Length{length(C)+1}=GSE_Length1+4;


% % % % % % % % % % % % % % % uni_gse_packet{length(C)+1}= uni_gse_packet1;




% % % %   % % % % % % % % % GENERATE PPPPPPPDUUUUUUUU   PPPPAAAAAACEEEEETTTTT
% % % % 
for lll=1:length(PDU_PCKT)
   aa1(lll)=hex2dec(PDU_PCKT(lll));
end

aa2=dec2bin(aa1,4);          PDU_LOAD=reshape(aa2,1,length(aa2)*4);         PDU_LOAD=aa2(1,:);  
for hhh=2:length(PDU_PCKT)
   PDU_LOAD= horzcat(PDU_LOAD,aa2(hhh,:));
end

CRC_GSE{Frag_ID_DECIM}=[ TOTALLL_LENGTHHH, PROTOCOLLL_TYPEEE, LABELLL,PDU_LOAD];

    crcCfg = crcConfig(Polynomial='z^32 + z^26 + z^23 + z^22 + z^16 + z^12 + z^11 + z^10 + z^8 + z^7 + z^5 + z^4 + z^2 + z + 1', ...
    InitialConditions=1,...
    ChecksumsPerFrame=1);

jj=length(CRC_GSE{Frag_ID_DECIM});
GSE_CRC_DOUBLE =[];
     for ii=1:jj(1)
         GSE_CRC_DOUBLE = horzcat( GSE_CRC_DOUBLE, bin2dec(CRC_GSE{Frag_ID_DECIM}(ii)));
     end

xxx=logical(GSE_CRC_DOUBLE)';
crcSeq = crcGenerate(xxx,crcCfg);
checkSum =  crcSeq(end-32+1:end)'

chkcrt=[]; 
for oo=1:length(checkSum)
    chk(oo)=num2str(checkSum(oo));
    chkcrt=[chkcrt,  chk(oo)]; 
end


chkcrt1=bin2dec(chkcrt);
chkcrt2=dec2hex(chkcrt1);
uni_gse_packet{length(C)+1}= [uni_gse_packet1,chkcrt2]



end